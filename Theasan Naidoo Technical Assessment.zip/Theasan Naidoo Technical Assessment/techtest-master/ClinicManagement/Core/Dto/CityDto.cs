﻿namespace ClinicManagement.Core.Dto
{
    public class CityDto
    {
        public byte Id { get; set; }
        public string Name { get; set; }
    }
}